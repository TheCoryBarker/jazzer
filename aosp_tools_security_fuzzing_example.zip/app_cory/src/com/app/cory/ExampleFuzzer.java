package com.app.cory;

import com.code_intelligence.jazzer.api.FuzzedDataProvider;

public class ExampleFuzzer {

    public static void fuzzerTestOneInput(FuzzedDataProvider data) {
        int magicNumber = 327;
        if (data.consumeInt() == magicNumber) {
          throw new UnsupportedOperationException("Fuzz error this error is hit");
        }
    }
}
